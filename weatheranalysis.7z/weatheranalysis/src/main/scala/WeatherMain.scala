package com.aimia.weather


/**
 * This programme section is the main entry point for Spark.
 *  The programme logic is as below:
 *  1. Read all the csv*.gz files using databricks csv package
 *  2. Reshape the data as the provided data is narrow i.e. use pivot to reshape the data
 *  3. Filter out bad data - more conditions required 
 *  4. Select only a few features 
 *  5. Create partial stats such as mean , median if needed - currently not added 
 *  6. Save various static views as partitioned parquet files in the HDFS
 *  7. These static views can be visualised/analysed using tools such as R
 *  
 *  NOTE: Due to time constraints exception handling, functional coding etc. was not implemented
 *
 *
 *  How to setup the environment to run the current program:
 *
 *
 *  1.	Upload all the *.gz files in HDFS and set appropriate (read only for Spark user ) permissions. 
 *      This is the argument(0) to spark submit job
 *      Also, create a HDFS location where the processed files i.e. static views will be stored.
 *      This is the argument(1) to spark submit job
 *
 *  2. mvn clean package to make a jar file
 *   
 *  3. Run the spark submit command: (Example command below):
 *
 *  spark-submit --master local[*]  --class "com.aimia.weather.WeatherMain" /home/users/pd/weatheranalysis-0.0.1-SNAPSHOT-jar-with-dependencies.jar  "hdfs://sandbox.hortonworks.com:8020/data/AIMIA/RAW/*"   "hdfs://sandbox.hortonworks.com:8020/data/AIMIA/PROCESSED/"
 *  
 *  4. This program can be extended to create more static views as required by data scientists
 */
 */



import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext._



object WeatherMain {
	def main(args: Array[String]): Unit = {



			val conf = new SparkConf()//parameters not optimised yet
			.setAppName("WEATHER ANALYSIS")
			.setMaster("local[2]") // only for testing/debugging code locally (while building comment out)

			val sc = new SparkContext(conf) //disable for local
			val sqlContext = new org.apache.spark.sql.SQLContext(sc)

			import sqlContext.implicits._
			//Hardcoded parameters - change later

			var fileLocation = args(0)
			var processedCompleteLocation = args(1)


			//	var fileLocation = "hdfs://sandbox.hortonworks.com:8020/data/AIMIA/RAW/*"
			//	var processedCompleteLocation = "hdfs://sandbox.hortonworks.com:8020/data/AIMIA/PROCESSED/"

			val df = sqlContext.read.format("com.databricks.spark.csv").option("inferSchema", "true").option("codec", "org.apache.hadoop.io.compress.GzipCodec").load(fileLocation)

			//Data reshaping i.e. create broad table from narrow table using pivot function. selected only few features that are relevant. This can be expanded if required
			val df2= df.groupBy("C0", "C1").pivot("C2", Seq("TMAX", "TMIN", "TOBS", "PRCP", "SNOW", "SNWD")).sum("C3")

			//filter out bad data - specify the criteria here. Expand as required.
       val df3 = df2.filter( ($"TMAX" isNotNull ) && ($"TMIN" isNotNull) )

			//rename the columns of Dataframe

			val df4 = df3.select($"C0".as("STATION"), $"C1".as("DATE").cast("string"), $"TMAX" , $"TMIN",  $"TOBS", $"PRCP", $"SNOW", $"SNWD")
			.withColumn("COUNTRY", $"STATION".substr(0,2))
			.withColumn("YEAR", $"DATE".substr(0,4))
			.withColumn("MONTH", $"DATE".substr(5,2))


			//df4.show  avoiding partitioning for now unless required - breaks on sandbox due to less
			// resources.partitionBy("STATION")

		// if parquet is required then write as parquet
	
			df4.coalesce(10).write.mode("overwrite").format("parquet").save(processedCompleteLocation+"/complete/parquet")

			// if csv format is required then use the following
			df4.coalesce(100).write.mode("overwrite").format("com.databricks.spark.csv").option("header", "true").save(processedCompleteLocation+"/complete/csv")




	}
}